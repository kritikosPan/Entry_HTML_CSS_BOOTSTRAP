let message = document.getElementById("submit");
message.addEventListener("click", FirstAdd);


function FirstAdd() {
  window.alert("Updated Successfully");
};